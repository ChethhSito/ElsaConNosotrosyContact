import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-usuarios',
  templateUrl: './view-usuarios.component.html',
  styleUrls: ['./view-usuarios.component.css']
})
export class ViewUsuariosComponent implements OnInit{
  usuarios: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;
  constructor(private usuariosService:UserService){

  }

  prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.usuarios.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedUsuarios():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.usuarios.slice(starIndex, endIndex);
  }
  ngOnInit():void{
    this.usuariosService.listarUsuarios().subscribe(
      (dato:any) => {
        this.usuarios = dato;
        this.calculateTotalPages();
        console.log(this.usuarios);
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los usuarios','error');
      }
    )
  }
  
}
