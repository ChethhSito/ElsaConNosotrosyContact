import { Component, OnInit } from '@angular/core';
import { ProveedorService } from 'src/app/services/proveedor.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-proveedores',
  templateUrl: './view-proveedores.component.html',
  styleUrls: ['./view-proveedores.component.css']
})
export class ViewProveedoresComponent implements OnInit{
  usuarios: any=[]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;

  constructor(private ProveedorService:ProveedorService){}

  /*
  updateBoolean() {
    // Send a request to update the boolean value in the backend
    this.ProveedorService.actualizarProveedor('/api/updateBoolean', { value: this.isChecked }).subscribe();
  }*/
  esNoIngresado(estadoId: number): boolean {
    return estadoId === 3;
  }
  
  CambiarCheckbox(proveedor: any): void {
    proveedor.estado_estado_id = 4;
    this.ProveedorService.actualizarProveedor(proveedor).subscribe(
      () => {
        console.log('Proveedor actualizado con éxito.');
      },
      (error) => {
        console.error('Error al actualizar el proveedor:', error);
        Swal.fire('Error', 'Error al actualizar el proveedor', 'error');
      }
    );
  }
  prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.usuarios.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedUsuarios():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.usuarios.slice(starIndex, endIndex);
  }
  ngOnInit():void{
    this.ProveedorService.listarProveedores().subscribe(
      (dato:any) => {
        this.usuarios = dato;
        this.calculateTotalPages();
        console.log(this.usuarios);
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los proveedores','error');
      }
    )
  }
}
