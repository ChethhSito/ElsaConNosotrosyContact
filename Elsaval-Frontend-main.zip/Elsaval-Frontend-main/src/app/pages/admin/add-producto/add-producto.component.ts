import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ElementoService } from 'src/app/services/elemento.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-producto',
  templateUrl: './add-producto.component.html',
  styleUrls: ['./add-producto.component.css']
})
export class AddProductoComponent implements OnInit {

  productoData = {
    producto: '',
    descripcion: '',
    almacen: {
      almacenId: ''
    },
    cantidad: '',
  };

  almacenOptions = [
    { value: '1', viewValue: 'Materiales' },
    { value: '2', viewValue: 'Equipos' },
    { value: '3', viewValue: 'Implementos' }
  ];
  constructor(
    private snack: MatSnackBar,
    private elementoService: ElementoService,
    private router: Router) { }
  ngOnInit(): void {

  }
  volverAProductos() {
    this.router.navigate(['/admin/productos']); 
  }
  guardarInformacion() {
    console.log(this.productoData);
    if (this.productoData.producto.trim() === '' || this.productoData.producto == null) {
      this.snack.open('El nombre del producto es requerido', '', {
        duration: 3000
      });
      return;
    }
  
    if (this.productoData.descripcion.trim() === '' || this.productoData.descripcion == null) {
      this.snack.open('La descripción es requerida', '', {
        duration: 3000
      });
      return;
    }
    if (this.productoData.almacen.almacenId.trim() === '' || this.productoData.almacen.almacenId== null) {
      this.snack.open('El almacén es requerido', '', {
        duration: 3000
      });
      return;
    }
  
    if (this.productoData.cantidad.trim() === '' || this.productoData.cantidad == null) {
      this.snack.open('La cantidad es requerida', '', {
        duration: 3000
      });
      return;
    }
    const cantidadRegex = /^[1-9]\d*$/;

    if (!cantidadRegex.test(this.productoData.cantidad)) {
      this.snack.open('La cantidad debe ser un número mayor que cero', '', {
        duration: 3000
      });
      return;
    }
  
    this.elementoService.agregarElemento(this.productoData).subscribe(
      (data) => {
        console.log(data);
        Swal.fire('Producto guardado', 'El producto ha sido guardado con exito', 'success');
        this.productoData = {
          producto: '',
          descripcion: '',
          almacen: {
            almacenId: ''
          },
          cantidad: '',
        }
        this.router.navigate(['/admin/productos'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar la información del productos', 'error');
      }
    )
  }
}
