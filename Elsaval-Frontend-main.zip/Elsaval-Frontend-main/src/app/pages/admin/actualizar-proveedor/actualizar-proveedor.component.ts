import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProveedorService } from 'src/app/services/proveedor.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-proveedor',
  templateUrl: './actualizar-proveedor.component.html',
  styleUrls: ['./actualizar-proveedor.component.css']
})
export class ActualizarProveedorComponent implements OnInit{
  a = {
    En_Curso: 1,
    Ingresado: 2,
    No_Ingresado: 3,
  };
  constructor(
    private route: ActivatedRoute,
    private proveedorService: ProveedorService,
    private router: Router
  ) {}

  proveedorId = 0;
  proveedor: any;

  ngOnInit(): void {
    this.proveedorId = this.route.snapshot.params['proveedorId'];
    this.proveedorService.obtenerProveedor(this.proveedorId).subscribe(
      (data) => {
        this.proveedor = data;
        console.log(this.proveedor);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  public actualizarDatos() {
    this.proveedorService.actualizarProveedor(this.proveedor).subscribe(
      (data) => {
        if (this.proveedor.estado.estadoId !== this.a.No_Ingresado) {
          Swal.fire(
            'Proveedor actualizado',
            'El proveedor ha sido actualizado con éxito',
            'success'
          ).then((e) => {
            this.router.navigate(['/admin/proveedores']);
          });
        } else {
          this.router.navigate(['/admin/proveedores']);
        }
      },
      (error) => {
        Swal.fire(
          'Error en el sistema',
          'No se ha podido actualizar la información del proveedor',
          'error'
        );
        console.log(error);
      }
    );
  }
}
