import { Component, OnInit } from '@angular/core';
import { SocioService } from 'src/app/services/socio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-socio',
  templateUrl: './view-socio.component.html',
  styleUrls: ['./view-socio.component.css']
})
export class ViewSocioComponent implements OnInit{
  socios: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;
   constructor(private sociosService:SocioService){}

   prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.socios.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedSocios():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.socios.slice(starIndex, endIndex);
  }
  ngOnInit(): void {
    this.sociosService.listarSocios().subscribe(
      (dato:any) => {
        this.socios = dato;
        this.calculateTotalPages();
        console.log(this.socios);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los socios','error');
      }
    )  
  }
  eliminarSocio(socioId:any){
    Swal.fire({
      title:'Eliminar Socio',
      text:'¿Estas seguro de eliminar la informacion de la lista?',
      icon:'warning',
      showCancelButton: true,
      confirmButtonColor:'#3085d6',
      cancelButtonColor:'#d33',
      confirmButtonText:'Eliminar',
      cancelButtonText:'Cancelar'
    }).then((result)=>{
      if(result.isConfirmed){
        this.sociosService.eliminarSocio(socioId).subscribe(
          (data)=>{
            this.socios = this.socios.filter((socio:any)=> socio.socioId != socioId);
            Swal.fire('Socio eliminado','El socio ha sido eliminado de la base de datos','success');

          },
          (error)=>{
            Swal.fire('Error','Error al eliminar el socio de la base de datos','error');
          }
        )
      }
    })
  }
}
