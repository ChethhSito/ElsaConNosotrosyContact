import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleLanchaComponent } from './detalle-lancha.component';

describe('DetalleLanchaComponent', () => {
  let component: DetalleLanchaComponent;
  let fixture: ComponentFixture<DetalleLanchaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DetalleLanchaComponent]
    });
    fixture = TestBed.createComponent(DetalleLanchaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
