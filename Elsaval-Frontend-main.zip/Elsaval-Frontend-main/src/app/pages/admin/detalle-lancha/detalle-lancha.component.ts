import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LanchaService } from 'src/app/services/lancha.service';
import { SocioService } from 'src/app/services/socio.service';

@Component({
  selector: 'app-detalle-lancha',
  templateUrl: './detalle-lancha.component.html',
  styleUrls: ['./detalle-lancha.component.css']
})
export class DetalleLanchaComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private socioService: SocioService,
    private lanchaService: LanchaService,
    private router: Router) { }

    lanchaId = 0;
    lancha: any;
    socios: any;

  ngOnInit(): void {
    this.lanchaId = this.route.snapshot.params['lanchaId'];
    this.lanchaService.obtenerLancha(this.lanchaId).subscribe(
      (data) => {
        this.lancha = data;
        console.log(this.lancha)
      },
      (error)=> {
        console.log(error);
      }
      )

    this.socioService.listarSocios().subscribe(
      (data:any) =>{
        this.socios = data;
      },
      (error)=>{
        alert('Error al cargar los usuarios')
      }
    )
  }
  

}
