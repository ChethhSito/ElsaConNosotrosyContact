import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { InvitadoService } from 'src/app/services/invitado.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-invitados',
  templateUrl: './view-invitados.component.html',
  styleUrls: ['./view-invitados.component.css']
})
export class ViewInvitadosComponent implements OnInit{
  invitados: any[] = [];
  currentPage = 1;
  rowsPerPage = 10;
  totalPages = 0;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private invitadosService: InvitadoService
  ) {}

  actualizarIngreso(invitado: any): void {
    this.invitadosService.actualizarInvitado(invitado).subscribe(
      () => {
        Swal.fire('Éxito', 'Estado de ingreso actualizado correctamente', 'success');
      },
      (error) => {
        console.log(error);
        Swal.fire('Error', 'Error al actualizar el estado de ingreso', 'error');
      }
    );
  }

  ngOnInit(): void {
    this.invitadosService.listarInvitados().subscribe(
      (dato: any) => {
        this.invitados = dato;
        this.calculateTotalPages();
        console.log(this.invitados);
      },
      (error) => {
        console.log(error);
        Swal.fire('Error', 'Error al cargar los invitados', 'error');
      }
    );
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.invitados.length / this.rowsPerPage);
    if (this.currentPage > this.totalPages) {
      this.currentPage = 1;
    }
  }

  displayedInvitados(): any[] {
    const startIndex = (this.currentPage - 1) * this.rowsPerPage;
    const endIndex = startIndex + this.rowsPerPage;
    return this.invitados.slice(startIndex, endIndex).map(invitado => {
      invitado.ingreso = !!invitado.ingreso; // Asegura que sea un booleano
      return invitado;
    });
  }
}
