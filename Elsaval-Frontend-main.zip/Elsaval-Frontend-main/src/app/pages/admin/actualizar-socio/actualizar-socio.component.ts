import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EspejoService } from 'src/app/services/espejo.service';
import { SocioService } from 'src/app/services/socio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-socio',
  templateUrl: './actualizar-socio.component.html',
  styleUrls: ['./actualizar-socio.component.css']
})
export class ActualizarSocioComponent implements OnInit {

  casas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  constructor(
    private route: ActivatedRoute,
    private socioService: SocioService,
    private espejoService: EspejoService,
    private router: Router) { }

  socioId = 0;
  socio: any;
  espejos: any;

  ngOnInit(): void {
    this.socioId = this.route.snapshot.params['socioId'];
    this.socioService.obtenerSocio(this.socioId).subscribe(
      (data) => {
        this.socio = data;
        console.log(this.socio)
      },
      (error) => {
        console.log(error);
      }
    )

    this.espejoService.listarEspejos().subscribe(
      (data: any) => {
        this.espejos = data;
      },
      (error) => {
        alert('Error al cargar los usuarios')
      }
    )
  }

  public actualizarDatos(){
    this.socioService.actualizarSocio(this.socio).subscribe(
      (data) => {
          Swal.fire('Socio actualizado','El Socio ha sido actualizado con exito', 'success').then(
            (e)=> {
              this.router.navigate(['/admin/socios']);
            }
          );
      },
      (error) =>{
        Swal.fire('Error en el sistema','No se ha podido actualizar la infomacion del socio', 'error');
        console.log(error);
      }
    )
  }

}
