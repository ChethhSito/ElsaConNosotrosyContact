import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLanchasComponent } from './view-lanchas.component';

describe('ViewLanchasComponent', () => {
  let component: ViewLanchasComponent;
  let fixture: ComponentFixture<ViewLanchasComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewLanchasComponent]
    });
    fixture = TestBed.createComponent(ViewLanchasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
