import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AlmacenService } from 'src/app/services/almacen.service';
import { ElementoService } from 'src/app/services/elemento.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-elemento',
  templateUrl: './add-elemento.component.html',
  styleUrls: ['./add-elemento.component.css']
})
export class AddElementoComponent implements OnInit{
  almacenes:any = [];

  elementosData = {
    nombre:'',
    propietario:'',
    precio:'',
    descripcion:'',
    activo:true,
    almacen:{
      almacenId:''
    }
  }
  constructor(
    private almacenService:AlmacenService, 
    private snack:MatSnackBar, 
    private elementoService:ElementoService,
    private router:Router){}
  
  ngOnInit(): void {
    this.almacenService.listarAlmacenes().subscribe(
      (dato:any) => {
        this.almacenes = dato;
        console.log(this.almacenes);
      },(error) =>{
        console.log(error);
        Swal.fire('Error !!','Error al cargar los datos','error')
      }
    )
  }
  guardarInformacion(){
    console.log(this.elementosData);
    if(this.elementosData.nombre.trim() == '' || this.elementosData.nombre == null){
      this.snack.open('El nombre de la lancha es requerido','',{
        duration:3000
      });
      return;
    }
    this.elementoService.agregarElemento(this.elementosData).subscribe(
      (data) =>{
        console.log(data);
        Swal.fire('Elemeto guardado','El elemento ha sido guardado con exito','success');
        this.elementosData = {
          nombre:'',
          propietario:'',
          precio:'',
          descripcion:'',
          activo:true,
          almacen:{
            almacenId:''
          }
        }
        this.router.navigate(['/admin/elementos'])
      },
      (error)=>{
        Swal.fire('Error','Error al guardar el elemento en el almacen','error');
      }
    )
  }
}
