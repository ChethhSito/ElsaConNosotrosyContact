import { Component, OnInit } from '@angular/core';
import { AlmacenService } from 'src/app/services/almacen.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-almacen',
  templateUrl: './view-almacen.component.html',
  styleUrls: ['./view-almacen.component.css']
})
export class ViewAlmacenComponent implements OnInit {
  almacenes: any[] = [

  ];
  currentPage = 1;
  rowsPerPage = 10;
  totalPages = 0;

  constructor(private almacenService: AlmacenService) {

  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.almacenes.length / this.rowsPerPage);
    if (this.currentPage > this.totalPages) {
      this.currentPage = 1;
    }
  }
  displayedAlamacen(): any[] {
    const starIndex = (this.currentPage - 1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.almacenes.slice(starIndex, endIndex);
  }

  ngOnInit(): void {

    this.almacenService.listarAlmacenes().subscribe(
      (dato: any) => {
        this.almacenes = dato;
        this.calculateTotalPages();
        console.log(this.almacenes);
      },
      (error) => {
        console.log(error)
        Swal.fire('Error!!', ' Error en el listado de almacenes', 'error');
      }
    )
  }

}
