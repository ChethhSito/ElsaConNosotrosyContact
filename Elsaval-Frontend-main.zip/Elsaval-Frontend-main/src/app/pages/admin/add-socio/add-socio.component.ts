import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { EspejoService } from 'src/app/services/espejo.service';
import { SocioService } from 'src/app/services/socio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-socio',
  templateUrl: './add-socio.component.html',
  styleUrls: ['./add-socio.component.css']
})
export class AddSocioComponent implements OnInit {
  espejos: any = [];

  sociosData = {
    nombres: '',
    apellidos: '',
    dni: '',
    correo: '',
    ce: '',
    celular: '',
    celemergencia: '',
    ncasa: '',
    espejo: {
      espejoId: ''
    }
  }
  casas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  constructor(private espejoService: EspejoService,
    private snack: MatSnackBar,
    private socioService: SocioService,
    private router: Router) { }
  ngOnInit(): void {
    this.espejoService.listarEspejos().subscribe(
      (dato: any) => {
        this.espejos = dato;
        console.log(this.espejos);
      }, (error) => {
        console.log(error);
        Swal.fire('Error !!', 'Error al cargar los datos', 'error')
      }
    )
  }
  guardarInformacion() {
    console.log(this.sociosData);
    if (this.sociosData.nombres.trim() == '' || this.sociosData.nombres == null) {
      this.snack.open('El nombre del socio es requerido', '', {
        duration: 3000
      });
      return;
    }
    this.socioService.agregarSocio(this.sociosData).subscribe(
      (data) => {
        console.log(data);
        Swal.fire('Empleado guardado', 'El socio ha sido guardado con exito', 'success');
        this.sociosData = {
          nombres: '',
          apellidos: '',
          dni: '',
          correo: '',
          ce: '',
          celular: '',
          celemergencia: '',
          ncasa: '',
          espejo: {
            espejoId: ''
          }
        }
        this.router.navigate(['/admin/socios'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar el informacion del socio', 'error');
      }
    )
  }

}
