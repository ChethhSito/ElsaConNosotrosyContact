import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { VehiculosService } from 'src/app/services/vehiculos.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-vehiculos',
  templateUrl: './actualizar-vehiculos.component.html',
  styleUrls: ['./actualizar-vehiculos.component.css']
})
export class ActualizarVehiculosComponent implements OnInit{
  estados = ['Disponible', 'En mantenimiento', 'Retirado','Malogrado'];

  constructor(
    private route: ActivatedRoute,
    private vehiculoService: VehiculosService,
    private router: Router) { }

    vehiculoId = 0;
    vehiculo: any;

    ngOnInit(): void {
      this.vehiculoId = this.route.snapshot.params['vehiculoId'];
      this.vehiculoService.obtenerVehiculo(this.vehiculoId).subscribe(
        (data) => {
          this.vehiculo = data;
          console.log(this.vehiculo)
        },
        (error) => {
          console.log(error);
        }
      )
    }
    public actualizarDatos(){
      this.vehiculoService.actualizarVehiculo(this.vehiculo).subscribe(
        (data) => {
            Swal.fire('vehiculo actualizado','La vehiculo ha sido actualizado con exito', 'success').then(
              (e)=> {
                this.router.navigate(['/admin/vehiculos']);
              }
            );
        },
        (error) =>{
          Swal.fire('Error en el sistema','No se ha podido actualizar la infomacion del vehiculo', 'error');
          console.log(error);
        }
      )
    }
}
