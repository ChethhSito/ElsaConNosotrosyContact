import { Component } from '@angular/core';
import { ImagenService } from 'src/app/services/imagen.service';

@Component({
  selector: 'app-imagen',
  templateUrl: './imagen.component.html',
  styleUrls: ['./imagen.component.css']
})
export class ImagenComponent {
  constructor(
    private imagenService : ImagenService
  ){}
  
  upload(event:any){
    const file = event.target.files[0];
    if(file){
      const formData = new FormData();
      formData.append('file', file);
      this.imagenService.uploadFile(formData)
        .subscribe(response => {
          console.log('response', response);
        })
    }
  }

}
