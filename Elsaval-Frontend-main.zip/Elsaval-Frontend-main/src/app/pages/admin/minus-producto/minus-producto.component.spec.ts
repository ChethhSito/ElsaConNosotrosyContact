import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MinusProductoComponent } from './minus-producto.component';

describe('MinusProductoComponent', () => {
  let component: MinusProductoComponent;
  let fixture: ComponentFixture<MinusProductoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MinusProductoComponent]
    });
    fixture = TestBed.createComponent(MinusProductoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
