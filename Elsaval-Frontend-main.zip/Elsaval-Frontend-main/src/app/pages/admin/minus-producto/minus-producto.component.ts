import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ElementoService } from 'src/app/services/elemento.service';
import { MovimientoService } from 'src/app/services/movimiento.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-minus-producto',
  templateUrl: './minus-producto.component.html',
  styleUrls: ['./minus-producto.component.css']
})

export class MinusProductoComponent implements OnInit{

  constructor(
    private route: ActivatedRoute,
    private elementoService: ElementoService,
    private movimientoService: MovimientoService,
    private router: Router
  ) { }

  elementoId = 0;
  elemento: any;
  cantidadDisminuir: number = 0;

  ngOnInit(): void {
    this.elementoId = this.route.snapshot.params['elemento_id'];
    this.elementoService.obtenerElemento(this.elementoId).subscribe(
      (data) => {
        this.elemento = data;
        console.log(this.elemento);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  volverAProductos() {
    this.router.navigate(['/admin/productos']); 
  }

  public actualizarDatos() {
    if (this.validarProducto()) {
      const nuevaCantidad = this.elemento.cantidad - this.cantidadDisminuir;
      this.elemento.cantidad = nuevaCantidad;
  
      this.elementoService.actualizarElemento(this.elemento).subscribe(
        (data) => {
          console.log('Elemento actualizado:', this.elemento);
  
          const movimiento = {
            cantidad: this.cantidadDisminuir,
            estado: 'Retirado',
            fecha: this.getCurrentDate(),
            almacen: {
              almacenId: this.elemento.almacen.almacenId,
            },
            producto: {
              elemento_id: this.elemento.elemento_id,
            },
          };

          console.log('Movimiento:', movimiento);
  
          this.movimientoService.agregarMovimiento(movimiento).subscribe(
            (dataMovimiento) => {
              Swal.fire('Cantidad actualizada y movimiento registrado', 'La cantidad ha sido actualizada y el movimiento ha sido registrado con éxito', 'success').then(
                (e) => {
                  this.router.navigate(['/admin/productos']);
                }
              );
            },
            (errorMovimiento) => {
              Swal.fire('Error en el sistema', 'No se ha podido registrar el movimiento', 'error');
              console.log(errorMovimiento);
            }
          );
        },
        (error) => {
          Swal.fire('Error en el sistema', 'No se ha podido actualizar la información del producto', 'error');
          console.log(error);
        }
      );
    }
  }

  validarProducto() {
    if (this.cantidadDisminuir <= 0) {
      Swal.fire('Error', 'La cantidad debe ser un número mayor que 0', 'error');
      return false;
    }
    if (this.cantidadDisminuir > this.elemento.cantidad) {
      Swal.fire('Error', 'La cantidad a retirar no puede ser mayor al stock actual', 'error');
      return false;
    }
    return true;
  }

  getCurrentDate(): string {
    const currentDate = new Date();
    return currentDate.toISOString();
  }
}