import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-actualizar-usuarios',
templateUrl: './actualizar-usuarios.component.html',
styleUrls: ['./actualizar-usuarios.component.css']
})
export class ActualizarUsuariosComponent {
constructor(
private route:ActivatedRoute,
private usuarioservice: UserService,
private router:Router){}

id = 0;
usuario:any;

ngOnInit():void{
this.id = this.route.snapshot.params['id'];
this.usuarioservice.obtenerUsuario(this.id).subscribe(
(data) => {
this.usuario = data;
console.log(this.usuario)
},
(error)=> {
console.log(error);
}
)
}

public actualizarDatos(){
this.usuarioservice.actualizarUsuario(this.id, this.usuario).subscribe(
(data) => {
Swal.fire('Usuario actualizado','El usuario ha sido actualizado con exito', 'success').then(
(e)=> {
this.router.navigate(['/admin/usuarios']);
}
);
},
(error) =>{
Swal.fire('Error en el sistema','No se ha podido actualizar el usuario', 'error');
console.log(error);
}
)
}
}
