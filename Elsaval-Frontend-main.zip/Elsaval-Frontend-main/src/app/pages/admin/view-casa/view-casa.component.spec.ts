import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCasaComponent } from './view-casa.component';

describe('ViewCasaComponent', () => {
  let component: ViewCasaComponent;
  let fixture: ComponentFixture<ViewCasaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewCasaComponent]
    });
    fixture = TestBed.createComponent(ViewCasaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
