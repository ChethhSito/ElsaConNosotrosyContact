import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { EspejoService } from 'src/app/services/espejo.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-espejos',
  templateUrl: './add-espejos.component.html',
  styleUrls: ['./add-espejos.component.css']
})
export class AddEspejosComponent implements OnInit{
  espejo={
    nombreu: '',
    pass: '',
    descripcion: '',
    rol:''
  }
  constructor(private espejoService:EspejoService, private snack:MatSnackBar, private router:Router){}
  
  ngOnInit(): void {
    
  }
  formSubmit(){
    if(this.espejo.nombreu.trim() == '' || this.espejo.nombreu == null){
      this.snack.open("El nick es requerido !!",'',{
        duration:3000
      })
      return;
    }
    this.espejoService.agregarEspejos(this.espejo).subscribe(
      (dato:any) => {
        this.espejo.nombreu = '';
        this.espejo.pass = '';
        this.espejo.descripcion = '';
        this.espejo.rol = '';
        Swal.fire('Usuario agregado','El usuarios ha sido agregado con exito', 'success');
        this.router.navigate(['/admin/espejos']);
      },
      (error) => {
        console.log(error);
        Swal.fire('Error','Error al guardar usuario','error')
      }
    )
  }

}
