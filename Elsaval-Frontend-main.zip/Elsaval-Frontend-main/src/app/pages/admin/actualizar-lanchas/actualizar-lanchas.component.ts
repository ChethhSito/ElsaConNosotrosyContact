import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LanchaService } from 'src/app/services/lancha.service';
import { SocioService } from 'src/app/services/socio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-lanchas',
  templateUrl: './actualizar-lanchas.component.html',
  styleUrls: ['./actualizar-lanchas.component.css']
})
export class ActualizarLanchasComponent implements OnInit{
  estados = ['Disponible', 'En mantenimiento', 'Retirado','Malogrado'];

  constructor(
    private route: ActivatedRoute,
    private socioService: SocioService,
    private lanchaService: LanchaService,
    private router: Router) { }

    lanchaId = 0;
    lancha: any;
    socios: any;
  ngOnInit(): void {
    this.lanchaId = this.route.snapshot.params['lanchaId'];
    this.lanchaService.obtenerLancha(this.lanchaId).subscribe(
      (data) => {
        this.lancha = data;
        console.log(this.lancha)
      },
      (error) => {
        console.log(error);
      }
    )

    this.socioService.listarSocios().subscribe(
      (data: any) => {
        this.socios = data;
      },
      (error) => {
        alert('Error al cargar los socios')
      }
    )
  }
  public actualizarDatos(){
    this.lanchaService.actualizarLancha(this.lancha).subscribe(
      (data) => {
          Swal.fire('lancha actualizado','La lancha ha sido actualizado con exito', 'success').then(
            (e)=> {
              this.router.navigate(['/admin/casas']);
            }
          );
      },
      (error) =>{
        Swal.fire('Error en el sistema','No se ha podido actualizar la infomacion de la lancha', 'error');
        console.log(error);
      }
    )
  }

}
