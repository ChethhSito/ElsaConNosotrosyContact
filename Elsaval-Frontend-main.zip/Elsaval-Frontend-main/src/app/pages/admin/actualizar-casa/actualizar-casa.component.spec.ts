import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActualizarCasaComponent } from './actualizar-casa.component';

describe('ActualizarCasaComponent', () => {
  let component: ActualizarCasaComponent;
  let fixture: ComponentFixture<ActualizarCasaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ActualizarCasaComponent]
    });
    fixture = TestBed.createComponent(ActualizarCasaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
