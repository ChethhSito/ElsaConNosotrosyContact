import { Component } from '@angular/core';
import { IngresosocioService } from 'src/app/services/ingresosocio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-ingresosocio',
  templateUrl: './view-ingresosocio.component.html',
  styleUrls: ['./view-ingresosocio.component.css']
})
export class ViewIngresosocioComponent {
  ingresosocio: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;
   constructor(private ingresosocioService:IngresosocioService){}

   prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.ingresosocio.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedIngresoSocios():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.ingresosocio.slice(starIndex, endIndex);
  }
  ngOnInit(): void {
    this.ingresosocioService.listarIngresoSocio().subscribe(
      (dato:any) => {
        this.ingresosocio = dato;
        this.calculateTotalPages();
        console.log(this.ingresosocio);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los ingresos','error');
      }
    )  
  }

}
