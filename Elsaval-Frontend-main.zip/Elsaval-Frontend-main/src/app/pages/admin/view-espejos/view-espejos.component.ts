import { Component, OnInit } from '@angular/core';
import { EspejoService } from 'src/app/services/espejo.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-espejos',
  templateUrl: './view-espejos.component.html',
  styleUrls: ['./view-espejos.component.css']
})
export class ViewEspejosComponent  implements OnInit{
  espejos: any[] = [

  ];
  currentPage = 1;
  rowsPerPage = 10;
  totalPages = 0;

  constructor(private espejosService: EspejoService) {

  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.espejos.length / this.rowsPerPage);
    if (this.currentPage > this.totalPages) {
      this.currentPage = 1;
    }
  }
  displayedEspejo(): any[] {
    const starIndex = (this.currentPage - 1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.espejos.slice(starIndex, endIndex);
  }

  ngOnInit(): void {

    this.espejosService.listarEspejos().subscribe(
      (dato: any) => {
        this.espejos = dato;
        this.calculateTotalPages();
        console.log(this.espejos);
      },
      (error) => {
        console.log(error)
        Swal.fire('Error!!', ' Error en el listado de almacenes', 'error');
      }
    )
  }
}
