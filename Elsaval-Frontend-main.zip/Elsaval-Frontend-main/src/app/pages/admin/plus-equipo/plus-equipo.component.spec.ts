import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlusEquipoComponent } from './plus-equipo.component';

describe('PlusEquipoComponent', () => {
  let component: PlusEquipoComponent;
  let fixture: ComponentFixture<PlusEquipoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PlusEquipoComponent]
    });
    fixture = TestBed.createComponent(PlusEquipoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
