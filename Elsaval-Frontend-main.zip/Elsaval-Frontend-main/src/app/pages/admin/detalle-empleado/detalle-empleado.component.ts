import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { EspejoService } from 'src/app/services/espejo.service';

@Component({
  selector: 'app-detalle-empleado',
  templateUrl: './detalle-empleado.component.html',
  styleUrls: ['./detalle-empleado.component.css']
})
export class DetalleEmpleadoComponent implements OnInit{
  
  constructor(
    private route: ActivatedRoute,
    private empleadoService: EmpleadosService,
    private espejoService: EspejoService,
    private router: Router) { }

  empleadoId = 0;
  empleado: any;
  espejos: any;
  
  ngOnInit(): void {
    this.empleadoId = this.route.snapshot.params['empleadoId'];
    this.empleadoService.obtenerEmpleado(this.empleadoId).subscribe(
      (data) => {
        this.empleado = data;
        console.log(this.empleado)
      },
      (error)=> {
        console.log(error);
      }
    )

    this.espejoService.listarEspejos().subscribe(
      (data:any) =>{
        this.espejos = data;
      },
      (error)=>{
        alert('Error al cargar los usuarios')
      }
    )
  }


}
