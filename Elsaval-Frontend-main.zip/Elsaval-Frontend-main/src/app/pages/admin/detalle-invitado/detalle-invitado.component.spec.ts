import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleInvitadoComponent } from './detalle-invitado.component';

describe('DetalleInvitadoComponent', () => {
  let component: DetalleInvitadoComponent;
  let fixture: ComponentFixture<DetalleInvitadoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DetalleInvitadoComponent]
    });
    fixture = TestBed.createComponent(DetalleInvitadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
