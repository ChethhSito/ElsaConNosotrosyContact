import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MinusEquipoComponent } from './minus-equipo.component';

describe('MinusEquipoComponent', () => {
  let component: MinusEquipoComponent;
  let fixture: ComponentFixture<MinusEquipoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MinusEquipoComponent]
    });
    fixture = TestBed.createComponent(MinusEquipoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
