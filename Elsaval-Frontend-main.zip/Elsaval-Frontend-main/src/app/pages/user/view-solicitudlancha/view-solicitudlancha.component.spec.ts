import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewSolicitudLanchaComponent } from './view-solicitudlancha.component';

describe('ViewEmpleadoComponent', () => {
  let component: ViewSolicitudLanchaComponent;
  let fixture: ComponentFixture<ViewSolicitudLanchaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewSolicitudLanchaComponent]
    });
    fixture = TestBed.createComponent(ViewSolicitudLanchaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
