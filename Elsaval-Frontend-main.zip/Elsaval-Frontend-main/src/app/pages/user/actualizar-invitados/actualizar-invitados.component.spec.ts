import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActualizarInvitadosComponent } from './actualizar-invitados.component';

describe('ActualizarInvitadosComponent', () => {
  let component: ActualizarInvitadosComponent;
  let fixture: ComponentFixture<ActualizarInvitadosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ActualizarInvitadosComponent]
    });
    fixture = TestBed.createComponent(ActualizarInvitadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
