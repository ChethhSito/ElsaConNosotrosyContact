import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { InvitadoService } from 'src/app/services/invitado.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-invitados',
  templateUrl: './actualizar-invitados.component.html',
  styleUrls: ['./actualizar-invitados.component.css']
})
export class ActualizarInvitadosComponent implements OnInit {

  casas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  constructor(
    private route: ActivatedRoute,
    private invitadoService: InvitadoService,
    private router: Router) { }

  invitadoId = 0;
  invitado: any;

  ngOnInit(): void {
    this.invitadoId = this.route.snapshot.params['invitadoId'];
    this.invitadoService.obtenerInvitado(this.invitadoId).subscribe(
      (data) => {
        this.invitado = data;
        console.log(this.invitado);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  public actualizarDatos() {
    if (this.validarInvitado(this.invitado)) {
      this.invitadoService.actualizarInvitado(this.invitado).subscribe(
        (data) => {
          Swal.fire('Invitado actualizado', 'El invitado ha sido actualizado con éxito', 'success').then(
            (e) => {
              this.router.navigate(['/user/invitados']);
            }
          );
        },
        (error) => {
          Swal.fire('Error en el sistema', 'No se ha podido actualizar la información del invitado', 'error');
          console.log(error);
        }
      );
    }
  }

  validarInvitado(invitado:any) {
    const letrasPattern = /^[A-Za-z\s]+$/;
    const dniPattern = /^\d{8}$/;
    const numeroPattern = /^(\d{7}|\d{9})$/;

    if (invitado.nombre.trim() === '' || invitado.nombre == null) {
      Swal.fire('Error', 'El nombre del invitado es requerido', 'error');
      return false;
    }

    if (invitado.apellido.trim() === '' || invitado.apellido == null) {
      Swal.fire('Error', 'El apellido del invitado es requerido', 'error');
      return false;
    }

    if (!letrasPattern.test(invitado.nombre)) {
      Swal.fire('Error', 'El nombre del invitado solo puede contener letras', 'error');
      return false;
    }

    if (!letrasPattern.test(invitado.apellido)) {
      Swal.fire('Error', 'El apellido del invitado solo puede contener letras', 'error');
      return false;
    }

    if (invitado.dni.trim() === '' || invitado.dni == null) {
      Swal.fire('Error', 'El DNI del invitado es requerido', 'error');
      return false;
    }

    if (!dniPattern.test(invitado.dni) || invitado.dni.length !== 8) {
      Swal.fire('Error', 'El DNI del invitado debe tener 8 caracteres numéricos', 'error');
      return false;
    }

    if (invitado.numero.trim() === '' || invitado.numero == null) {
      Swal.fire('Error', 'El número del invitado es requerido', 'error');
      return false;
    }

    if (!numeroPattern.test(invitado.numero) || (invitado.numero.length !== 7 && invitado.numero.length !== 9)) {
      Swal.fire('Error', 'El número del invitado debe tener 7 (número de casa) o 9 (número de celular) caracteres numéricos', 'error');
      return false;
    }

    if (invitado.ncasa === '' || invitado.ncasa == null) {
      Swal.fire('Error', 'El número de casa del invitado es requerido', 'error');
      return false;
    }

    return true;
  }
}
