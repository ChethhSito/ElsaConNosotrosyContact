import { Component, OnInit } from '@angular/core';
import { ProveedorService } from 'src/app/services/proveedor.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-proveedores',
  templateUrl: './proveedores.component.html',
  styleUrls: ['./proveedores.component.css']
})
export class ProveedoresComponent implements OnInit{
  proveedores: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;
   constructor(private proveedorService:ProveedorService){}

   prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.proveedores.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedProveedores():any[]{
    const startIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = startIndex + this.rowsPerPage;
    return this.proveedores.slice(startIndex, endIndex);
  }
  ngOnInit(): void {
    this.proveedorService.listarProveedores().subscribe(
      (dato:any) => {
        this.proveedores = dato;
        this.calculateTotalPages();
        console.log(this.proveedores);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los proveedores','error');
      }
    )  
  }
}
