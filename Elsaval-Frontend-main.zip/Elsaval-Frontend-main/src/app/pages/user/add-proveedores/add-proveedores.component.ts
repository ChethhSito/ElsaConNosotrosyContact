import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ProveedorService } from 'src/app/services/proveedor.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-proveedores',
  templateUrl: './add-proveedores.component.html',
  styleUrls: ['./add-proveedores.component.css']
})
export class AddProveedoresComponent implements OnInit {

  proveedoresData = {
    razonsocial: '',
    ruc: '',
    numero: '',
    producto: '',
    fecha: new Date(),
    estado: {
      estadoId: 1,
    }
  }
  fechaActual = this.proveedoresData.fecha.toLocaleDateString('es-ES', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric'
  });

  constructor(
    private snack: MatSnackBar,
    private invitadoService: ProveedorService,
    private router: Router) { }
  ngOnInit(): void {

  }
  guardarInformacion() {
    console.log(this.proveedoresData);
    const rucPattern = /^(20|10|15|16|17)\d{9}$/;
    const numeroPattern = /^(\d{7}|\d{9})$/;
    if (this.proveedoresData.razonsocial.trim() === '' || this.proveedoresData.razonsocial == null) {
      this.snack.open('La razon social es requerida', '', {
        duration: 3000
      });
      return;
    }
  
    if (this.proveedoresData.ruc.trim() === '' || this.proveedoresData.ruc == null) {
      this.snack.open('El RUC es requerido', '', {
        duration: 3000
      });
      return;
    }
    if (this.proveedoresData.numero.trim() === '' || this.proveedoresData.numero == null) {
      this.snack.open('El número es requerido', '', {
        duration: 3000
      });
      return;
    }
  
    if (this.proveedoresData.producto.trim() === '' || this.proveedoresData.producto == null) {
      this.snack.open('El nombre del producto es requerido', '', {
        duration: 3000
      });
      return;
    }
    
    if (!rucPattern.test(this.proveedoresData.ruc)) {
      this.snack.open('El RUC no tiene un formato válido', '', {
        duration: 3000
      });
      return;
    }

    if (!numeroPattern.test(this.proveedoresData.numero) || (this.proveedoresData.numero.length !== 7 && this.proveedoresData.numero.length !== 9)) {
      this.snack.open('El número del invitado debe tener 7 (número de casa) o 9 (número de celular) caracteres numéricos', '', {
        duration: 3000
      });
      return;
    }
    this.invitadoService.agregarProveedor(this.proveedoresData).subscribe(
      (data) => {
        console.log(data);
        Swal.fire('Ingreso proveedor guardado', 'El ingreso de proveedor ha sido guardado con exito', 'success');
        this.proveedoresData = {
          razonsocial: '',
          ruc: '',
          numero: '',
          producto: '',
          fecha: new Date(),
          estado: {
            estadoId: 3,
          }
        }
        this.router.navigate(['/user/proveedores'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar la informacion del proveedor', 'error');
      }
    )
  }
}