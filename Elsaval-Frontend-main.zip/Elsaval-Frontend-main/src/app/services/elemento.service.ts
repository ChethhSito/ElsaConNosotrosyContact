import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class ElementoService {

  constructor(private http:HttpClient) { }

  public listarElementos(){
    return this.http.get(`${baserUrl}/productos/`);
  }

  public agregarElemento(elemento:any){
    return this.http.post(`${baserUrl}/productos/`, elemento);
  }

  public eliminarElemento(elementoId:any){
    return this.http.delete(`${baserUrl}/productos/${elementoId}`);
  }
  public obtenerElemento(elementoId:any){
    return this.http.get(`${baserUrl}/productos/${elementoId}`);
  }
  public actualizarElemento(elemento:any){
    return this.http.put(`${baserUrl}/productos/`, elemento);
  }
}