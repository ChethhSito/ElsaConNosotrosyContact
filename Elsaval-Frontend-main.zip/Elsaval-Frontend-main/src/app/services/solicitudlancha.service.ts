import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class SolicitudLanchaService {

  constructor(private http:HttpClient) { }

  public listarSolicitudes(){
    return this.http.get(`${baserUrl}/solicitudlancha/`);
  }
  public agregarSolicitud(solicitudlancha:any){
    return this.http.post(`${baserUrl}/solicitudlancha/`, solicitudlancha)
  }
}
