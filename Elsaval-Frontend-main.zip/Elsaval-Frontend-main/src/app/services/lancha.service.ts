import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class LanchaService {

  constructor(private http: HttpClient){}

  public listarLanchas(){
    return this.http.get(`${baserUrl}/lancha/`);
  }
  public agregarLancha(lancha:any){
    return this.http.post(`${baserUrl}/lancha/`, lancha)
  }
  public eliminarLancha(lanchaId:any){
    return this.http.delete(`${baserUrl}/lancha/${lanchaId}`)
  }
  public obtenerLancha(lanchaId:any){
    return this.http.get(`${baserUrl}/lancha/${lanchaId}`);
  }
  public actualizarLancha(lancha:any){
    return this.http.put(`${baserUrl}/lancha/`, lancha);
  }
}
