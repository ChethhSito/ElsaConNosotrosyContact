import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class MovimientoService {

  constructor(private http:HttpClient) { }

  public listarMovimientos(){
    return this.http.get(`${baserUrl}/productos2/`);
  }

  public agregarMovimiento(movimiento:any){
    return this.http.post(`${baserUrl}/productos2/`, movimiento);
  }

  public eliminarMovimiento(movimientoId:any){
    return this.http.delete(`${baserUrl}/productos2/${movimientoId}`);
  }
  public obtenerMovimiento(movimientoId:any){
    return this.http.get(`${baserUrl}/productos2/${movimientoId}`);
  }
  public actualizarMovimiento(movimiento:any){
    return this.http.put(`${baserUrl}/productos2/`, movimiento);
  }
}
