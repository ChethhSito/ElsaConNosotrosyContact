import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class InfoempleadoService {

  constructor(private http:HttpClient) { }

  public listarInfoEmpleados(){
    return this.http.get(`${baserUrl}/infoempleados/`);
  }
  public guardarInfoEmpleado(infoempleado:any){
    return this.http.post(`${baserUrl}/infoempleados/`, infoempleado);
  }
  
}
