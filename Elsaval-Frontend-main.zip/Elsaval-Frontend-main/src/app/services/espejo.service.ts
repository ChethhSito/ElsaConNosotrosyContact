import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class EspejoService {

  constructor(private http:HttpClient) { }

  public listarEspejos(){
    return this.http.get(`${baserUrl}/espejo/`);
  }

  public agregarEspejos(espejo:any){
    return this.http.post(`${baserUrl}/espejo/`,espejo);
  }
}
