import { TestBed } from '@angular/core/testing';

import { EquipoMovimientoService } from './equipomovimiento.service';

describe('EquipoMovimientoService', () => {
  let service: EquipoMovimientoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EquipoMovimientoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
