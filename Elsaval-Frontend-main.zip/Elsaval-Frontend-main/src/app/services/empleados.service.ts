import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class EmpleadosService {

  constructor(private http:HttpClient) { }

  public listarEmpleados(){
    return this.http.get(`${baserUrl}/empleado/`);
  }
  public agregarEmpleado(empleado:any){
    return this.http.post(`${baserUrl}/empleado/`, empleado)
  }
  public eliminarEmpleado(empleadoId: any){
    return this.http.delete(`${baserUrl}/empleado/${empleadoId}`)
  }
  public obtenerEmpleado(empleadoId:any){
    return this.http.get(`${baserUrl}/empleado/${empleadoId}`);
  }
  public actualizarEmpleado(empleado:any){
    return this.http.put(`${baserUrl}/empleado/`, empleado);
  }
}
