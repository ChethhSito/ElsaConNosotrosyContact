import { TestBed } from '@angular/core/testing';

import { IngresosocioService } from './ingresosocio.service';

describe('IngresosocioService', () => {
  let service: IngresosocioService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IngresosocioService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
